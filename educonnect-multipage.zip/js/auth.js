import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js";
import { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup,
         signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-firestore.js";
import { firebaseConfig } from "./js/firebase-init.js";
import { $, guard } from "./js/utils.js";

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export function mountHeader(active=""){
  const el = document.querySelector(".header .nav");
  if(!el) return;
  el.querySelectorAll("a").forEach(a=>{
    if(a.getAttribute("data-active")==active) a.classList.add("active");
  });
}

export async function ensureUserDoc(uid, email){
  const ref = doc(db, "users", uid);
  const snap = await getDoc(ref);
  if(!snap.exists()){
    await setDoc(ref, { email, role: "student", createdAt: serverTimestamp() });
    return { uid, email, role: "student" };
  }
  return { uid, email, ...snap.data() };
}

export function onUser(cb){
  onAuthStateChanged(auth, async (u)=>{
    if(!u){ cb(null); return; }
    const profileRef = doc(db, "users", u.uid);
    const snap = await getDoc(profileRef);
    const user = snap.exists()? { uid: u.uid, email: u.email, ...snap.data() } : await ensureUserDoc(u.uid, u.email);
    cb(user);
  });
}

export async function doEmailSignUp(email, pass){
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  return ensureUserDoc(cred.user.uid, email);
}
export async function doEmailSignIn(email, pass){
  await signInWithEmailAndPassword(auth, email, pass);
}
export async function doGoogle(){
  const provider = new GoogleAuthProvider();
  const res = await signInWithPopup(auth, provider);
  return ensureUserDoc(res.user.uid, res.user.email);
}
export async function doSignOut(){ await signOut(auth); }

// Simple helper to set avatar initials
export function initials(email){ return (email||'?')[0].toUpperCase(); }
